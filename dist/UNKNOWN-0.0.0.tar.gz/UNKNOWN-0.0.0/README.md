1. Download the pyhton file from the given link. https://drive.google.com/drive/folders/1ebqWUF06mkLRpmV-AjAjPMYgmh0cuUvX
2. Setup the environment for Anaconda Prompt.
``` conda create --name mle-dev ```
3. Activate the mle-dev environment. ``` conda activate mle-dev ```
4. Install the required libraries (pandas, numpy, matplotlib, scikit-learn,scipy). ```conda install numpy pandas matplotlib scikit-learn scipy```
5. Run the command python file in anaconda prompt .```python nonstandardcode.py``` 
6. Export environment file as env.yml. ```conda export > env.yml```